# ============================================================
#  TWITCH IRC
# ============================================================
import re
import socket
import time
import threading

from config import BOT_NICK, AUTH_TOKEN
from logger import log

EMOJI_RE = re.compile(
    "[\U00002600-\U000027BF"
    "\U0001F300-\U0001F9FF"
    "\U0001FA00-\U0001FA6F"
    "\U0001FA70-\U0001FAFF"
    "\U00002702-\U000027B0"
    "\U0000FE00-\U0000FE0F"
    "\U0001F1E0-\U0001F1FF]"
)


def has_emoji(text: str) -> bool:
    return bool(EMOJI_RE.search(text))


def has_promo_separator(text: str) -> bool:
    return bool(re.search(r'\|{2,}', text))


def is_mod_or_vip(tags_str: str) -> bool:
    if not tags_str:
        return False
    if re.search(r'\bmod=1\b', tags_str):
        return True
    if re.search(r'\bvip=1\b', tags_str):
        return True
    badges_match = re.search(r'badges=([^;]*)', tags_str)
    if badges_match:
        badges = badges_match.group(1)
        if any(b in badges for b in ['moderator', 'vip', 'broadcaster']):
            return True
    return False


def parse_promos_emoji(raw_text: str) -> list:
    """Фильтр emoji: ищет 26-символьные коды разделённые ||."""
    clean  = re.sub(r'[^A-Z0-9|]', '', raw_text.upper())
    clean  = re.sub(r'\|{2,}', ' ', clean).replace('|', ' ')
    promos = [p for p in clean.split() if len(p) == 26]
    return list(dict.fromkeys(promos))


def parse_promos_clean(raw_text: str) -> list:
    """
    Фильтр clean: точная логика по описанию.
    Условия сообщения:
      - >= 150 буквенно-цифровых символов (A-Z, 0-9)
      - слова разделены пробелами
      - каждое слово (промокод) начинается на 01 и длина 26 символов
    """
    # Проверка: >= 150 alphanumeric символов
    alphanum_len = len(re.sub(r'[^A-Za-z0-9]', '', raw_text))
    if alphanum_len < 150:
        return []
    # Токенизируем по пробелам/переносам, чистим каждый токен
    tokens = raw_text.split()
    promos = []
    for t in tokens:
        clean_t = re.sub(r'[^A-Z0-9]', '', t.upper())
        if len(clean_t) == 26 and clean_t.startswith('01'):
            promos.append(clean_t)
    return list(dict.fromkeys(promos))


def parse_promos(raw_text: str, filter_type: str = "emoji") -> list:
    """Универсальный парсер — выбирает нужный фильтр."""
    if filter_type == "clean":
        return parse_promos_clean(raw_text)
    return parse_promos_emoji(raw_text)


def _parse_privmsg(line: str):
    """Надёжный regex парсинг IRC PRIVMSG."""
    m = re.match(r'^(@\S+ )?:(\w+)!\S+ PRIVMSG #(\S+) :(.*)$', line)
    if not m:
        return None, None, None, None
    tags_str = (m.group(1) or "").strip()
    user     = m.group(2)
    channel  = m.group(3)
    message  = m.group(4)
    return tags_str, user, channel, message


def listen_twitch(get_channels_fn, distribute_fn, tg_fn, integration_trigger_fn=None):
    import state
    import queue as _queue
    seen_promos  = set()
    joined_chans = set()

    while True:
        try:
            channels_cfg = get_channels_fn()
            channels     = list(channels_cfg.keys()) if isinstance(channels_cfg, dict) else list(channels_cfg)
            sock = socket.socket()
            sock.settimeout(300)
            sock.connect(("irc.chat.twitch.tv", 6667))
            sock.send(f"PASS {AUTH_TOKEN}\r\n".encode("utf-8"))
            sock.send(f"NICK {BOT_NICK}\r\n".encode("utf-8"))
            sock.send("CAP REQ :twitch.tv/tags twitch.tv/commands\r\n".encode("utf-8"))

            joined_chans = set()
            for ch in channels:
                sock.send(f"JOIN #{ch}\r\n".encode("utf-8"))
                joined_chans.add(ch)
            filters_info = ', '.join(f"#{c}({v})" for c,v in (channels_cfg.items() if isinstance(channels_cfg, dict) else {c:"emoji" for c in channels}.items()))
            log(None, f"Слушаю: {filters_info}...")

            buffer = ""
            while True:
                try:
                    # Динамический JOIN из очереди (не вызываем get_channels_fn на каждом recv)
                    try:
                        while True:
                            ch = state.irc_join_queue.get_nowait()
                            if ch not in joined_chans:
                                sock.send(f"JOIN #{ch}\r\n".encode("utf-8"))
                                joined_chans.add(ch)
                                log(None, f"Динамически подключился к #{ch}")
                    except _queue.Empty:
                        pass

                    data = sock.recv(4096).decode("utf-8", errors="ignore")
                    if not data:
                        raise ConnectionResetError("Соединение закрыто")

                    buffer += data
                    lines   = buffer.split("\r\n")
                    buffer  = lines.pop()

                    for line in lines:
                        if not line:
                            continue
                        if "PING" in line and "PRIVMSG" not in line:
                            sock.send("PONG :tmi.twitch.tv\r\n".encode("utf-8"))
                            continue
                        if "PRIVMSG" not in line:
                            continue

                        try:
                            tags_str, user, channel, message = _parse_privmsg(line)
                            if not user:
                                continue

                            # Получаем конфиг каналов ОДИН РАЗ на сообщение
                            ch_cfg      = get_channels_fn()
                            ft          = ch_cfg.get(channel, "emoji") if isinstance(ch_cfg, dict) else "emoji"

                            if is_mod_or_vip(tags_str):
                                log(None, f"[{channel}/{ft}] [{user}] {message[:80]}")

                            # Триггер интеграции: donatov.net в любом сообщении
                            if ("donatov.net" in message.lower() or "donatovnet" in message.lower()) and integration_trigger_fn:
                                integration_trigger_fn(channel)

                            if not is_mod_or_vip(tags_str):
                                continue
                            # emoji фильтр требует эмодзи и разделитель, clean — нет
                            if ft == "emoji":
                                if not has_emoji(message):
                                    continue
                                if not has_promo_separator(message):
                                    continue

                            promos = parse_promos(message, ft)
                            if not promos:
                                # Дебаг: что нашли но не прошло длину
                                dbg = re.sub(r'[^A-Z0-9]', ' ', message.upper()).split()
                                found = [p for p in dbg if len(p) > 10]
                                if found:
                                    log(None, f"⚠️ [{channel}/{ft}] Не 26 символов: {[(p, len(p)) for p in found[:3]]}")
                                continue

                            # Dedupe
                            if len(seen_promos) > 50:
                                seen_promos.clear()
                            new_promos = [p for p in promos if p not in seen_promos]
                            if not new_promos:
                                log(None, "Dedupe — все коды уже обработаны, пропуск")
                                continue
                            seen_promos.update(new_promos)
                            irc_time = time.time()
                            log(None, f"[{user}] {len(new_promos)} новых промо: {new_promos}")
                            tg_fn(f"📨 <b>Промокоды в чате!</b>\n👤 {user}\n🎟 {len(new_promos)} код(ов): <code>{' '.join(new_promos)}</code>")
                            threading.Thread(target=distribute_fn, args=(new_promos, irc_time), daemon=True).start()

                        except Exception as e:
                            log(None, f"IRC parse error: {str(e)[:80]}")

                except socket.timeout:
                    log(None, "Таймаут — переподключение...")
                    break

        except Exception as e:
            log(None, f"IRC ошибка: {e}. Повтор через 5 сек...")
            time.sleep(5)
