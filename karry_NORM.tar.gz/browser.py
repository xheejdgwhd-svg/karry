# ============================================================
#  БРАУЗЕР — setup, watchdog, start/stop
# ============================================================
import os
import time
import threading
import atexit

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from config import (
    BASE_PROFILE_PATH, TARGET_URL, INPUT_SELECTOR, ACCOUNTS_COUNT
)
from logger import log
from state  import drivers, drivers_lock

CDP_STEALTH = """
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    Object.defineProperty(navigator, 'plugins',   { get: () => [1, 2, 3, 4, 5] });
    Object.defineProperty(navigator, 'languages', { get: () => ['ru-RU', 'ru', 'en-US', 'en'] });
    window.chrome = { runtime: {} };
    const _orig = EventTarget.prototype.dispatchEvent;
    EventTarget.prototype.dispatchEvent = function(event) {
        try { Object.defineProperty(event, 'isTrusted', { get: () => true }); } catch(_) {}
        return _orig.call(this, event);
    };
"""


def setup_browser(acc_id: int):
    options = Options()
    user_dir = os.path.join(BASE_PROFILE_PATH, f"acc_{acc_id}")
    os.makedirs(user_dir, exist_ok=True)

    options.page_load_strategy = 'eager'
    options.add_argument("--headless=new")
    options.add_argument(f"--user-data-dir={user_dir}")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--log-level=3")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument(f"--remote-debugging-port={9220 + acc_id}")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    options.set_capability("goog:loggingPrefs", {"performance": "ALL"})

    try:
        driver = webdriver.Chrome(options=options)
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {"source": CDP_STEALTH})
        log(acc_id, "Подключение...")
        driver.get(TARGET_URL)
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, INPUT_SELECTOR))
        )
        log(acc_id, "Готов.")
        from http_activator import init_session, start_xsrf_prefetch
        if init_session(driver, acc_id):
            start_xsrf_prefetch(acc_id)
        return driver
    except Exception as e:
        log(acc_id, f"Ошибка запуска: {e}")
        return None


def start_all_browsers():
    from state import drivers, drivers_lock
    with drivers_lock:
        for d in drivers:
            try: d.quit()
            except: pass
        drivers.clear()
    results = [None] * ACCOUNTS_COUNT
    def launch(idx):
        results[idx] = setup_browser(idx + 1)
    threads = [threading.Thread(target=launch, args=(i,), daemon=True) for i in range(ACCOUNTS_COUNT)]
    for t in threads: t.start()
    for t in threads: t.join()
    for d in results:
        if d:
            with drivers_lock:
                drivers.append(d)
    log(None, f"Браузеры запущены: {len(drivers)}/{ACCOUNTS_COUNT}")


def stop_all_browsers():
    from state import drivers, drivers_lock
    from http_activator import drop_session
    log(None, "Остановка браузеров...")
    with drivers_lock:
        for i, d in enumerate(drivers, 1):
            try: d.quit()
            except: pass
            drop_session(i)
        drivers.clear()
    os.system('pkill -f chrome 2>/dev/null; pkill -f chromedriver 2>/dev/null')
    log(None, "Браузеры остановлены")


def browser_watchdog():
    """Проверяет каждые 15 сек живы ли браузеры и авторизацию."""
    from state import drivers, drivers_lock
    try:
        from telegram_bot import tg
    except ImportError:
        tg = lambda msg: None
    while True:
        time.sleep(15)
        with drivers_lock:
            current = list(drivers)
        for idx, driver in enumerate(current):
            acc_id = idx + 1
            try:
                url = driver.current_url
                if "login" in url and "activate" not in url:
                    log(acc_id, "⚠️ Watchdog: разлогинился — перезапуск...")
                    tg(f"⚠️ <b>Watchdog</b>: Акк {acc_id} разлогинился")
                    new_driver = setup_browser(acc_id)
                    if new_driver:
                        with drivers_lock:
                            if idx < len(drivers):
                                drivers[idx] = new_driver
                        log(acc_id, "✅ Watchdog: авторизация восстановлена")
                        tg(f"✅ <b>Watchdog</b>: Акк {acc_id} восстановлен")
                    else:
                        log(acc_id, "❌ Watchdog: не удалось восстановить")
                        tg(f"❌ <b>Watchdog</b>: Акк {acc_id} не восстановился")
            except Exception:
                log(acc_id, "⚠️ Watchdog: браузер упал — перезапуск...")
                tg(f"⚠️ <b>Watchdog</b>: Акк {acc_id} упал")
                new_driver = setup_browser(acc_id)
                if new_driver:
                    with drivers_lock:
                        if idx < len(drivers):
                            drivers[idx] = new_driver
                    log(acc_id, "✅ Watchdog: восстановлен")
                    tg(f"✅ <b>Watchdog</b>: Акк {acc_id} восстановлен")
                else:
                    log(acc_id, "❌ Watchdog: не восстановился")
                    tg(f"❌ <b>Watchdog</b>: Акк {acc_id} не восстановился")


def cleanup():
    log(None, "Остановка...")
    from state import drivers, drivers_lock
    with drivers_lock:
        for d in drivers:
            try: d.quit()
            except: pass

atexit.register(cleanup)
