"""
WORKER — запускается на каждом VPS (1 аккаунт)
Принимает HTTP запросы от Controller и активирует промокод.

Запуск: python3 worker.py
"""
import json
import time
import threading
import os
import urllib.request
from http.server import HTTPServer, BaseHTTPRequestHandler

from config  import TARGET_URL, INPUT_SELECTOR, BASE_PROFILE_PATH
from logger  import log
from browser import setup_browser, browser_watchdog
from http_activator import init_session, activate_http
from activation import _activate_selenium

# ── КОНФИГ ВОРКЕРА ─────────────────────────────────────────
WORKER_PORT    = int(os.getenv("WORKER_PORT", "8080"))
WORKER_SECRET  = os.getenv("WORKER_SECRET", "secret123")   # токен авторизации
ACC_ID         = int(os.getenv("ACC_ID", "1"))             # номер аккаунта

# ── СОСТОЯНИЕ ──────────────────────────────────────────────
_driver      = None
_driver_lock = threading.Lock()
_log_buffer  = []  # последние 100 строк логов
_log_lock    = threading.Lock()

# URL main-бота для отправки логов
MAIN_URL    = os.getenv("MAIN_URL", "")     # http://MAIN_IP:8090
MAIN_SECRET = os.getenv("WORKER_SECRET", "secret123")


def _send_log_to_main(acc_id: int, msg: str):
    """Отправляет лог на main который пересылает в TG."""
    if not MAIN_URL:
        return
    try:
        body = json.dumps({"acc_id": acc_id, "msg": msg}).encode()
        req  = urllib.request.Request(
            f"{MAIN_URL}/worker_log",
            data=body,
            headers={"Content-Type": "application/json", "X-Worker-Secret": MAIN_SECRET},
            method="POST"
        )
        urllib.request.urlopen(req, timeout=3)
    except Exception:
        pass


def worker_log(acc_id: int, msg: str):
    """Логирует локально + шлёт на main."""
    log(acc_id, msg)
    with open(f"/home/ubuntu/bot/worker_{ACC_ID}.log", "a") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] [Акк {acc_id}] {msg}\n")
    line = f"[{time.strftime('%H:%M:%S')}] [Акк {acc_id}] {msg}"
    with _log_lock:
        _log_buffer.append(line)
        if len(_log_buffer) > 100:
            _log_buffer.pop(0)
    # Важные события шлём в TG через main
    important = any(w in msg for w in ["✅", "❌", "💀", "HTTP check", "HTTP activate"])
    if important:
        threading.Thread(target=_send_log_to_main, args=(acc_id, msg), daemon=True).start()


def start_browser():
    global _driver
    log(ACC_ID, "Запускаю браузер...")
    d = setup_browser(ACC_ID)
    if d:
        with _driver_lock:
            _driver = d
        log(ACC_ID, "✅ Браузер готов")
    else:
        log(ACC_ID, "❌ Браузер не запустился")

# ── HTTP HANDLER ───────────────────────────────────────────
class WorkerHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        pass  # отключаем стандартные логи

    def _auth(self) -> bool:
        token = self.headers.get("X-Worker-Secret", "")
        return token == WORKER_SECRET

    def _respond(self, status: int, data: dict):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if not self._auth():
            self._respond(401, {"error": "Unauthorized"})
            return

        if self.path == "/activate":
            length = int(self.headers.get("Content-Length", 0))
            body   = json.loads(self.rfile.read(length))
            code   = body.get("code", "")
            if not code:
                self._respond(400, {"error": "No code"})
                return

            with _driver_lock:
                d = _driver

            if not d:
                self._respond(503, {"error": "Browser not ready"})
                return

            log(ACC_ID, f"Получен код: {code}")
            open(f'/home/ubuntu/bot/worker_{ACC_ID}.log', 'a').write(f'[{time.strftime("%H:%M:%S")}] START {code}\n')
            t0 = time.time()

            # HTTP активация
            result = activate_http(d, ACC_ID, code)
            if result["success"]:
                elapsed = result["elapsed"]
                log(ACC_ID, f"✅ HTTP УСПЕХ за {elapsed}с | {code}")
                self._respond(200, {"success": True, "elapsed": elapsed, "method": "http"})
                return

            msg         = result["message"].lower()
            status_code = result.get("status_code", 0)

            # 400 — мусорный / невалидный код, пропуск
            if status_code == 400 or "invalid" in msg:
                log(ACC_ID, f"HTTP 400: невалидный код {code} — пропуск")
                self._respond(200, {"success": False, "elapsed": round(time.time()-t0, 2), "method": "skip_400"})
                return

            # 404 / not_found — код не найден или уже использован, пропуск без Selenium
            if status_code == 404 or any(w in msg for w in ["not_found", "не найден", "not found", "недоступен", "already", "активирован ранее", "уже использован"]):
                log(ACC_ID, f"HTTP 404: код не найден {code} — пропуск")
                self._respond(200, {"success": False, "elapsed": round(time.time()-t0, 2), "method": "skip_404"})
                return

            # Всё остальное (rate_limit 429, timeout, неизвестная ошибка) — Selenium fallback
            reason = "rate_limit" if (status_code == 429 or "rate_limit" in msg) else f"http_{status_code}"
            log(ACC_ID, f"HTTP {reason}: {result['message'][:80]} → Selenium fallback")

            sel_ok = False
            try:
                sel_ok = _activate_selenium(d, code, ACC_ID)
            except Exception as e:
                log(ACC_ID, f"Selenium exception: {e}")

            elapsed = round(time.time() - t0, 2)
            self._respond(
                200 if sel_ok else 500,
                {"success": sel_ok, "elapsed": elapsed, "method": "selenium"}
            )
            return

        elif self.path == "/start_browser":
            worker_log(ACC_ID, "▶️ Старт браузера по команде TG...")
            def _do_start():
                global _driver
                with _driver_lock:
                    if _driver:
                        try: _driver.quit()
                        except: pass
                    _driver = None
                new_d = setup_browser(ACC_ID)
                if new_d:
                    init_session(new_d, ACC_ID)
                    with _driver_lock:
                        _driver = new_d
                    worker_log(ACC_ID, "✅ Браузер запущен")
                else:
                    worker_log(ACC_ID, "❌ Не удалось запустить браузер")
            threading.Thread(target=_do_start, daemon=False).start()
            self._respond(200, {"ok": True})
            return

        elif self.path == "/stop_browser":
            worker_log(ACC_ID, "⏹ Стоп браузера по команде TG...")
            def _do_stop():
                global _driver
                with _driver_lock:
                    if _driver:
                        try: _driver.quit()
                        except: pass
                    _driver = None
                worker_log(ACC_ID, "✅ Браузер остановлен")
            threading.Thread(target=_do_stop, daemon=True).start()
            self._respond(200, {"ok": True})
            return

        elif self.path == "/restart_browser":
            worker_log(ACC_ID, "🔄 Перезапуск браузера по команде TG...")
            def _do_restart():
                global _driver
                with _driver_lock:
                    if _driver:
                        try: _driver.quit()
                        except: pass
                    _driver = None
                new_d = setup_browser(ACC_ID)
                if new_d:
                    init_session(new_d, ACC_ID)
                    with _driver_lock:
                        _driver = new_d
                    worker_log(ACC_ID, "✅ Браузер перезапущен")
                else:
                    worker_log(ACC_ID, "❌ Не удалось перезапустить браузер")
            threading.Thread(target=_do_restart, daemon=False).start()
            self._respond(200, {"ok": True})
            return

        elif self.path == "/logs":
            with _log_lock:
                logs = list(_log_buffer)
            self._respond(200, {"logs": logs})
            return

        elif self.path == "/test_activate":
            # Проверочная активация с заведомо несуществующим кодом
            # Доказывает что воркер принимает задачи и ходит на donatov.net
            TEST_CODE = "01TEST00000000000000000000"
            with _driver_lock:
                d = _driver
            if not d:
                self._respond(503, {"ok": False, "error": "Браузер не запущен", "acc_id": ACC_ID})
                return
            t0 = time.time()
            try:
                result = activate_http(d, ACC_ID, TEST_CODE)
                elapsed = round(time.time() - t0, 2)
                status_code = result.get("status_code", 0)
                # 404 = код не найден = воркер работает корректно
                # 400 = невалидный формат = тоже норм, сервер ответил
                alive = status_code in (400, 404) or not result["success"]
                self._respond(200, {
                    "ok":          alive,
                    "acc_id":      ACC_ID,
                    "elapsed":     elapsed,
                    "status_code": status_code,
                    "message":     result.get("message", "")[:100],
                })
            except Exception as e:
                self._respond(200, {"ok": False, "acc_id": ACC_ID, "error": str(e)[:100]})
            return

        self._respond(404, {"error": "Not found"})

    def do_GET(self):
        if self.path == "/ping":
            with _driver_lock:
                d = _driver
            browser_ok = False
            url = ""
            try:
                url = d.current_url if d else ""
                browser_ok = d is not None
            except Exception:
                browser_ok = False
            self._respond(200, {"ok": True, "acc_id": ACC_ID, "browser": browser_ok, "url": url})

        elif self.path == "/balance":
            if not self._auth():
                self._respond(401, {"error": "Unauthorized"})
                return
            with _driver_lock:
                d = _driver
            if not d:
                self._respond(503, {"ok": False, "error": "Браузер не запущен"})
                return
            try:
                import time as _t
                from config import ACCOUNT_EMAILS
                email   = ACCOUNT_EMAILS.get(ACC_ID, f"Акк {ACC_ID}")
                cur_url = d.current_url
                d.get("https://donatov.net/profile")
                _t.sleep(2)
                try:
                    balance = d.execute_script(
                        "var el = document.querySelector('.dcoin_val'); return el ? el.innerText : '?';"
                    )
                except Exception:
                    balance = "?"
                d.get(cur_url)
                self._respond(200, {"ok": True, "acc_id": ACC_ID, "email": email, "balance": balance})
            except Exception as e:
                self._respond(200, {"ok": False, "acc_id": ACC_ID, "error": str(e)[:100]})

        else:
            self._respond(404, {"error": "Not found"})


# ── MAIN ───────────────────────────────────────────────────
if __name__ == "__main__":
    # Запускаем браузер
    threading.Thread(target=start_browser, daemon=False).start()

    # Watchdog
    threading.Thread(target=browser_watchdog, daemon=True).start()

    # HTTP сервер
    server = HTTPServer(("0.0.0.0", WORKER_PORT), WorkerHandler)
    log(ACC_ID, f"Worker запущен на порту {WORKER_PORT}")
    server.serve_forever()
