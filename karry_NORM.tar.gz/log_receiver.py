"""
Простой HTTP сервер на main-bot для приёма логов с воркеров.
Запускается автоматически из main.py в отдельном потоке.
"""
import json
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
import os

RECEIVER_PORT   = int(os.getenv("LOG_RECEIVER_PORT", "8090"))
WORKER_SECRET   = os.getenv("WORKER_SECRET", "secret123")


class LogHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        pass

    def _auth(self) -> bool:
        return self.headers.get("X-Worker-Secret", "") == WORKER_SECRET

    def _respond(self, status: int, data: dict):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if not self._auth():
            self._respond(401, {"error": "Unauthorized"})
            return

        if self.path == "/worker_log":
            length = int(self.headers.get("Content-Length", 0))
            body   = json.loads(self.rfile.read(length))
            acc_id = body.get("acc_id", "?")
            msg    = body.get("msg", "")
            # Пересылаем в TG
            try:
                from telegram_bot import tg
                tg(f"🖥 <b>Воркер {acc_id}:</b> {msg}")
            except Exception:
                pass
            self._respond(200, {"ok": True})
            return

        self._respond(404, {"error": "Not found"})


def start_log_receiver():
    """Запускает сервер приёма логов в фоновом потоке."""
    server = HTTPServer(("0.0.0.0", RECEIVER_PORT), LogHandler)
    t = threading.Thread(target=server.serve_forever, daemon=True, name="LogReceiver")
    t.start()
    from logger import log
    log(None, f"LogReceiver запущен на порту {RECEIVER_PORT}")
