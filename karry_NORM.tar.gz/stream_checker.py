# ============================================================
#  STREAM CHECKER — следит за статусом стрима через Twitch API
# ============================================================
import urllib.request
import urllib.parse
import json
import time
import threading

from config import TWITCH_CLIENT_ID, TWITCH_CLIENT_SECRET
from logger import log

_token            = None
_token_expiry     = 0
_token_lock       = threading.Lock()
_stream_live      = False   # текущий известный статус
_last_known_state = None    # синхронизация с TG callback (True/False/None)

# Интеграционный режим
_integration_lock = threading.Lock()
INTEGRATION_TTL   = 60  # секунд задержки перед выключением (стандартный режим)

# Контейнер — накапливает ссылки donatov.net по каждому каналу
# {channel: [timestamp1, timestamp2, ...]}
_containers      = {}
CONTAINER_COUNT  = 3   # сколько ссылок нужно для триггера
CONTAINER_WINDOW = 90  # за сколько секунд

# Состояние после триггера
_main_channel   = None   # канал который сейчас управляет таймером
_timer_start    = None   # когда запустился текущий таймер (30 мин или стажер)
_intern_started = None   # когда запустился стажер (None = стажер ещё не активен)
_had_promos     = False  # были ли промо в текущей сессии
_last_promo_time = None  # когда последний раз пришли промо
_notified_promo  = False # чтобы не спамить в TG

TIMEOUT_MAIN   = 30 * 60  # 30 мин — основной таймер после триггера
TIMEOUT_INTERN =  5 * 60  #  5 мин — стажер


def notify_integration_promo():
    """Вызывается из distribute_promos когда пришли промокоды."""
    global _last_promo_time, _had_promos
    _last_promo_time = time.time()
    _had_promos      = True


def _get_token() -> str:
    """Получает app access token от Twitch. Обновляет за 5 мин до истечения."""
    global _token, _token_expiry
    with _token_lock:
        if _token and time.time() < _token_expiry - 300:
            return _token
        url  = "https://id.twitch.tv/oauth2/token"
        data = urllib.parse.urlencode({
            "client_id":     TWITCH_CLIENT_ID,
            "client_secret": TWITCH_CLIENT_SECRET,
            "grant_type":    "client_credentials",
        }).encode()
        resp   = urllib.request.urlopen(url, data=data, timeout=10)
        result = json.loads(resp.read().decode())
        _token        = result["access_token"]
        _token_expiry = time.time() + result.get("expires_in", 3600 * 24 * 60)
        return _token


def is_stream_live(channel: str) -> bool:
    """Возвращает True если стример сейчас онлайн."""
    try:
        token = _get_token()
        url   = f"https://api.twitch.tv/helix/streams?user_login={channel}"
        req   = urllib.request.Request(url, headers={
            "Client-ID":     TWITCH_CLIENT_ID,
            "Authorization": f"Bearer {token}",
        })
        resp = urllib.request.urlopen(req, timeout=10)
        data = json.loads(resp.read().decode())
        return len(data.get("data", [])) > 0
    except Exception as e:
        log(None, f"[StreamChecker] Ошибка проверки стрима: {e}")
        return False


def set_known_state(state):
    """Вызывается из TG callback чтобы синхронизировать stream_worker."""
    global _last_known_state
    _last_known_state = state



def on_integration_trigger(channel: str, bot_state: dict, start_fn):
    """
    Вызывается из IRC когда в чате канала замечен donatov.net.
    Накапливает ссылки в контейнере канала.
    Если контейнер заполнился (3 ссылки за 90 сек) — триггер.
    """
    global _main_channel, _timer_start, _intern_started, _had_promos, _last_promo_time, _notified_promo

    if bot_state.get("bot_mode") != "integration":
        return

    # Игнорируем если стример оффлайн
    if not is_stream_live(channel):
        log(None, f"🔗 [{channel}] donatov.net замечен но стрим оффлайн — игнорируем")
        return

    now = time.time()

    with _integration_lock:
        # Добавляем ссылку в контейнер канала, чистим старые
        if channel not in _containers:
            _containers[channel] = []
        _containers[channel].append(now)
        _containers[channel] = [t for t in _containers[channel] if now - t <= CONTAINER_WINDOW]
        count = len(_containers[channel])
        log(None, f"🔗 [{channel}] контейнер: {count}/{CONTAINER_COUNT} за {CONTAINER_WINDOW}с")

        if count < CONTAINER_COUNT:
            return  # контейнер ещё не заполнен

        # Контейнер заполнен — триггер
        _containers[channel] = []  # сбрасываем контейнер

        if _main_channel is None:
            # Никто не управляет — этот канал становится main
            _main_channel    = channel
            _timer_start     = now
            _intern_started  = None
            _had_promos      = False
            _last_promo_time = None
            _notified_promo  = False
            log(None, f"🔗 [{channel}] контейнер заполнен — становится main, таймер 30 мин")
            from telegram_bot import tg_send, main_keyboard
            tg_send(f"🔗 <b>Интеграция началась!</b> #{channel} — запускаю браузеры (таймер 30 мин)", main_keyboard())
            from state import drivers, drivers_lock
            with drivers_lock:
                browsers_running = len(drivers) > 0
            if not browsers_running:
                threading.Thread(target=start_fn, daemon=True).start()
        else:
            # Уже есть main — этот канал перехватывает управление, сброс на 30 мин
            old_main = _main_channel
            _main_channel    = channel
            _timer_start     = now
            _intern_started  = None
            _had_promos      = False
            _last_promo_time = None
            _notified_promo  = False
            log(None, f"🔗 [{channel}] контейнер заполнен — перехватывает у #{old_main}, сброс на 30 мин")
            from telegram_bot import tg_send, main_keyboard
            tg_send(f"🔗 <b>Новая интеграция!</b> #{channel} перехватил у #{old_main} — таймер сброшен на 30 мин", main_keyboard())


def integration_worker(bot_state: dict, start_fn, stop_fn):
    """
    Фоновый поток для режима 'integration'.

    Контейнерная логика:
    - Контейнер канала заполнился → main, таймер 30 мин
    - За 30 мин пришли промо → стажер 5 мин
    - За 30 мин промо не было → всё равно стажер 5 мин
    - Стажер истёк → выключаемся
    - Новый контейнер заполнился в любой момент → сброс на 30 мин

    Стандартный режим (без контейнера): следим за статусом стрима через Twitch API.
    """
    global _main_channel, _timer_start, _intern_started, _had_promos, _last_promo_time, _notified_promo
    log(None, "IntegrationWorker запущен...")
    _shutdown_pending = {}  # для стандартного режима

    while True:
        time.sleep(20)

        if bot_state.get("bot_mode") != "integration":
            continue

        # --- Под-режим: контейнер + таймеры ---
        if bot_state.get("integration_shutdown_after_promo"):
            with _integration_lock:
                main_ch = _main_channel

            if main_ch is None:
                continue  # ждём первого триггера

            now = time.time()

            with _integration_lock:
                t_start  = _timer_start
                t_intern = _intern_started
                had_p    = _had_promos
                last_p   = _last_promo_time

            if t_intern is not None:
                # Стажер активен — считаем от его старта
                elapsed  = now - t_intern
                remained = TIMEOUT_INTERN - elapsed
                log(None, f"[Integration] стажер: осталось {int(remained)}с / {TIMEOUT_INTERN}с")

                if elapsed >= TIMEOUT_INTERN:
                    # Стажер истёк — выключаемся
                    from state import drivers, drivers_lock
                    with drivers_lock:
                        browsers_running = len(drivers) > 0
                    if browsers_running:
                        log(None, "📴 Интеграция: стажер истёк — останавливаю браузеры")
                        from telegram_bot import tg_send, main_keyboard
                        tg_send("📴 <b>Интеграция завершена</b> — 5 мин без активности", main_keyboard())
                        threading.Thread(target=stop_fn, daemon=True).start()
                    with _integration_lock:
                        _main_channel    = None
                        _timer_start     = None
                        _intern_started  = None
                        _had_promos      = False
                        _last_promo_time = None
                        _notified_promo  = False
                        _containers.clear()

            else:
                # Основной таймер 30 мин
                elapsed  = now - t_start
                remained = TIMEOUT_MAIN - elapsed
                log(None, f"[Integration] main таймер #{main_ch}: осталось {int(remained)}с / {TIMEOUT_MAIN}с")

                if elapsed >= TIMEOUT_MAIN:
                    # 30 мин истекло — запускаем стажера независимо от промо
                    with _integration_lock:
                        _intern_started = now
                    reason = "промо были" if had_p else "промо не было"
                    log(None, f"[Integration] 30 мин истекло ({reason}) — запускаю стажера 5 мин")
                    from telegram_bot import tg_send, main_keyboard
                    tg_send(f"⏱ 30 мин истекло ({reason}) — последние <b>5 мин</b>", main_keyboard())

                elif had_p and last_p and not _notified_promo:
                    # Промо пришли раньше 30 мин — сразу запускаем стажера
                    with _integration_lock:
                        _intern_started = now
                        _notified_promo = True
                    log(None, "[Integration] промо получены — запускаю стажера 5 мин досрочно")
                    from telegram_bot import tg_send, main_keyboard
                    tg_send("⏱ Промокоды получены — последние <b>5 мин</b>", main_keyboard())

            continue  # в этом режиме Twitch API не проверяем

        # --- Стандартный режим: Twitch API ---
        with _integration_lock:
            main_ch = _main_channel

        if main_ch is None:
            continue

        alive = is_stream_live(main_ch)
        if alive:
            _shutdown_pending.pop(main_ch, None)
        else:
            if main_ch not in _shutdown_pending:
                _shutdown_pending[main_ch] = time.time() + INTEGRATION_TTL
                log(None, f"📴 [{main_ch}] стрим закончился — выключение через {INTEGRATION_TTL}с")

            if time.time() >= _shutdown_pending[main_ch]:
                from state import drivers, drivers_lock
                with drivers_lock:
                    browsers_running = len(drivers) > 0
                if browsers_running:
                    log(None, f"📴 [{main_ch}] интеграция завершена — останавливаю браузеры")
                    from telegram_bot import tg_send, main_keyboard
                    tg_send("📴 <b>Интеграция завершена</b> — стрим закончился", main_keyboard())
                    threading.Thread(target=stop_fn, daemon=True).start()
                with _integration_lock:
                    _main_channel = None
                    _containers.clear()
                _shutdown_pending.pop(main_ch, None)



def stream_worker(bot_state: dict, start_fn, stop_fn):
    """
    Фоновый поток — проверяет статус стримов каждые 60 сек.
    Логика:
    - Браузеры запускаются если хотя бы 1 стример онлайн И браузеры ещё не запущены
    - Браузеры останавливаются только если ВСЕ стримеры офлайн
    - При добавлении нового стримера: проверяет реальное состояние браузеров
    """
    global _stream_live, _last_known_state
    log(None, "StreamChecker запущен...")

    while True:
        time.sleep(60)

        if bot_state["bot_mode"] != "schedule":
            _last_known_state = None
            continue

        # Получаем список каналов (поддерживаем dict и list)
        channels_cfg = bot_state.get("channels", {"t2x2": "emoji"})
        ch_list = list(channels_cfg.keys()) if isinstance(channels_cfg, dict) else list(channels_cfg)

        # Проверяем статус каждого стримера отдельно
        statuses = {ch: is_stream_live(ch) for ch in ch_list}
        any_live  = any(statuses.values())
        all_dead  = not any_live
        _stream_live = any_live

        live_list = [ch for ch, s in statuses.items() if s]
        log(None, f"StreamChecker: {statuses} → any_live={any_live}")

        from state import drivers, drivers_lock
        with drivers_lock:
            local_running = len(drivers) > 0
        # Считаем браузеры запущенными если хотя бы main-бот готов
        # (воркеры запускаются параллельно через start_all_workers)
        browsers_running = local_running

        if any_live and not browsers_running:
            # Стрим есть, браузеров нет — запускаем
            log(None, f"📡 Стрим онлайн ({', '.join(live_list)}) — запускаю браузеры")
            from telegram_bot import tg_send, main_keyboard
            tg_send(f"📡 <b>Стрим начался!</b> ({', '.join('#'+c for c in live_list)}) — запускаю браузеры", main_keyboard())
            threading.Thread(target=start_fn, daemon=True).start()
            _last_known_state = True

        elif all_dead and browsers_running:
            # Все стримеры офлайн, браузеры работают — останавливаем
            log(None, "📴 Все стримы закончились — останавливаю браузеры")
            from telegram_bot import tg_send, main_keyboard
            tg_send("📴 <b>Все стримы закончились</b> — останавливаю браузеры", main_keyboard())
            threading.Thread(target=stop_fn, daemon=True).start()
            _last_known_state = False

        elif any_live and browsers_running:
            # Всё нормально — стрим идёт, браузеры работают
            _last_known_state = True

        elif all_dead and not browsers_running:
            # Всё офлайн, браузеры выключены — норма
            _last_known_state = False


def get_stream_status(channels) -> dict:
    ch_list = list(channels.keys()) if isinstance(channels, dict) else channels
    result  = {}
    for ch in ch_list:
        result[ch] = is_stream_live(ch)
    return result
