#!/bin/bash
WORKER_IPS=(
    "18.156.136.208"
    "3.78.254.12"
    "3.75.219.67"
    "3.74.166.103"
)
SSH_USER="ubuntu"
BOT_DIR="~/bot"
SSH_KEY="~/.ssh/workers_key"

FILES=(
    "activation.py"
    "http_activator.py"
    "browser.py"
    "config.py"
    "logger.py"
    "state.py"
    "worker.py"
)

echo "=== Деплой на ${#WORKER_IPS[@]} воркеров ==="
for i in "${!WORKER_IPS[@]}"; do
    IP="${WORKER_IPS[$i]}"
    ACC_ID=$((i + 2))
    echo ""
    echo "--- Воркер $ACC_ID ($IP) ---"
    for f in "${FILES[@]}"; do
        scp -i "$SSH_KEY" -o StrictHostKeyChecking=no \
            "$f" "${SSH_USER}@${IP}:${BOT_DIR}/" 2>/dev/null
    done
    ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no \
        "${SSH_USER}@${IP}" \
        "pkill -f worker.py 2>/dev/null; sleep 1; \
         cd ${BOT_DIR} && \
         ACC_ID=${ACC_ID} WORKER_SECRET=secret123 MAIN_URL=http://3.124.205.13:8090 \
         nohup python3 -u worker.py > worker.log 2>&1 &" 2>/dev/null
    echo "✅ Воркер $ACC_ID перезапущен"
done
echo "=== Готово ==="
