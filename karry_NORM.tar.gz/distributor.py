"""
DISTRIBUTOR — заменяет distribute_promos на controller.
Шлёт промокоды воркерам с небольшими задержками (антибот).

Импортируется в activation.py вместо старой distribute_promos.
"""
import json
import time
import threading
import urllib.request
import urllib.error
import os

from logger import log

# ── КОНФИГ ВОРКЕРОВ ────────────────────────────────────────
# Заполни IP каждого VPS
WORKERS = [
    {"id": 1, "url": "http://3.75.141.206:8080"},   # main-bot
    {"id": 2, "url": "http://18.156.136.208:8080"},   # worker-1
    {"id": 3, "url": "http://3.78.254.12:8080"},   # worker-2
    {"id": 4, "url": "http://3.75.219.67:8080"},   # worker-3
    {"id": 5, "url": "http://3.74.166.103:8080"},   # worker-4
]
WORKER_SECRET = os.getenv("WORKER_SECRET", "secret123")
# Кеш готовности браузеров — обновляется в фоне каждые 5с
_browser_ready = {}
_browser_ready_lock = threading.Lock()

def _start_readiness_monitor():
    def _loop():
        while True:
            for w in WORKERS:
                try:
                    req  = urllib.request.Request(f"{w['url']}/ping")
                    resp = urllib.request.urlopen(req, timeout=2)
                    data = json.loads(resp.read().decode())
                    ready = data.get("browser", False)
                except Exception:
                    ready = False
                with _browser_ready_lock:
                    _browser_ready[w["id"]] = ready
            time.sleep(5)
    threading.Thread(target=_loop, daemon=True, name="readiness-monitor").start()

_start_readiness_monitor()

import random

STAGGER_MS_MIN = 120
STAGGER_MS_MAX = 260


def _send_to_worker(worker: dict, code: str, irc_time: float = None):
    """Отправляет код одному воркеру."""
    t0 = time.time()
    if irc_time:
        log(None, f"[W{worker['id']}] ⏱ IRC→worker: {round(t0 - irc_time, 3)}с")

    # Проверяем кеш готовности — без блокирующего /ping в hot-path
    with _browser_ready_lock:
        ready = _browser_ready.get(worker["id"], False)

    if not ready:
        deadline = time.time() + 60
        while time.time() < deadline:
            time.sleep(1)
            with _browser_ready_lock:
                ready = _browser_ready.get(worker["id"], False)
            if ready:
                break
        else:
            log(None, f"[W{worker['id']}] ⏱ Браузер не готов за 60с — пропуск")
            return

    try:
        body = json.dumps({"code": code}).encode()
        req  = urllib.request.Request(
            f"{worker['url']}/activate",
            data=body,
            headers={
                "Content-Type":    "application/json",
                "X-Worker-Secret": WORKER_SECRET,
            },
            method="POST",
        )
        resp     = urllib.request.urlopen(req, timeout=15)
        result   = json.loads(resp.read().decode())
        elapsed  = round(time.time() - t0, 2)
        success  = result.get("success", False)
        method   = result.get("method", "?")
        log(None, f"[W{worker['id']}] {'✅' if success else '❌'} {method} {elapsed}с | {code}")

    except urllib.error.HTTPError as e:
        log(None, f"[W{worker['id']}] HTTP {e.code}: {e.read().decode()[:100]}")
    except Exception as e:
        log(None, f"[W{worker['id']}] Ошибка: {str(e)[:100]}")


def distribute_promos(promos: list, irc_time: float = None):
    """
    Раздаёт промокоды воркерам с задержкой STAGGER_MS между каждым.
    Выглядит как разные люди, не как бот.
    """
    if not promos:
        return

    # Уведомляем integration_worker что промо пришли — сжимает таймер с 15 до 5 мин
    try:
        from stream_checker import notify_integration_promo
        notify_integration_promo()
    except Exception:
        pass

    count = min(len(promos), len(WORKERS))
    log(None, f"Раздача {count}/{len(promos)} кодов воркерам (stagger={STAGGER_MS_MIN}-{STAGGER_MS_MAX}мс рандом)")

    for i in range(count):
        worker = WORKERS[i]
        code   = promos[i]
        # Stagger убран — каждый воркер активирует свой уникальный код
        # поэтому rate-limit по одному коду не срабатывает
        # Минимальная задержка = максимальная скорость
        delay  = 0.0

        def _task(w=worker, c=code, d=delay, t=irc_time):
            if d > 0:
                time.sleep(d)
            _send_to_worker(w, c, t)

        threading.Thread(target=_task, daemon=True).start()


def get_workers_status() -> list:
    """Проверяет статус всех воркеров — для TG статуса."""
    results = []
    def _check(w):
        try:
            # Пробуем /status
            req  = urllib.request.Request(
                f"{w['url']}/status",
                headers={"X-Worker-Secret": WORKER_SECRET},
            )
            resp = urllib.request.urlopen(req, timeout=5)
            data = json.loads(resp.read().decode())
            if "error" not in data:
                results.append({"id": w["id"], "ok": True, "browser": True, "url": w["url"], **data})
                return
        except Exception:
            pass
        # Fallback — /ping
        try:
            req  = urllib.request.Request(f"{w['url']}/ping")
            resp = urllib.request.urlopen(req, timeout=5)
            data = json.loads(resp.read().decode())
            results.append({"id": w["id"], "ok": True, "browser": data.get("ok", False), "url": w["url"]})
        except Exception as e:
            results.append({"id": w["id"], "ok": False, "error": str(e)[:50], "url": w["url"]})

    threads = [threading.Thread(target=_check, args=(w,), daemon=True) for w in WORKERS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=6)
    return sorted(results, key=lambda r: r["id"])


def _worker_cmd(url: str, path: str) -> bool:
    """Отправляет команду воркеру. Возвращает True если успешно."""
    try:
        req  = urllib.request.Request(
            f"{url}{path}",
            data=b"{}",
            headers={"Content-Type": "application/json", "X-Worker-Secret": WORKER_SECRET},
            method="POST"
        )
        urllib.request.urlopen(req, timeout=30)
        return True
    except Exception:
        return False


def start_all_workers() -> dict:
    """Запускает браузеры на всех воркерах. Возвращает {acc_id: ok}."""
    results = {}
    lock = threading.Lock()
    def _start(w):
        ok = _worker_cmd(w["url"], "/start_browser")
        with lock:
            results[w["id"]] = ok
    threads = [threading.Thread(target=_start, args=(w,), daemon=True) for w in WORKERS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=35)
    return results


def stop_all_workers() -> dict:
    """Останавливает браузеры на всех воркерах. Возвращает {acc_id: ok}."""
    results = {}
    lock = threading.Lock()
    def _stop(w):
        ok = _worker_cmd(w["url"], "/stop_browser")
        with lock:
            results[w["id"]] = ok
    threads = [threading.Thread(target=_stop, args=(w,), daemon=True) for w in WORKERS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=35)
    return results


def restart_all_workers() -> dict:
    """Перезапускает браузеры на всех воркерах."""
    results = {}
    lock = threading.Lock()
    def _restart(w):
        ok = _worker_cmd(w["url"], "/restart_browser")
        with lock:
            results[w["id"]] = ok
    threads = [threading.Thread(target=_restart, args=(w,), daemon=True) for w in WORKERS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=35)
    return results
