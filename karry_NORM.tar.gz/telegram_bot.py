# ============================================================
#  TELEGRAM BOT — уведомления, кнопки, polling
# ============================================================
import json
import time
import threading
import datetime
import urllib.request
import urllib.parse

from config import TG_TOKEN, TG_CHAT_ID, ACCOUNTS_COUNT, ACCOUNT_EMAILS
from logger import log

# ============================================================
#  БАЗОВЫЕ ФУНКЦИИ
# ============================================================
def tg(msg: str):
    try:
        url  = f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage"
        data = urllib.parse.urlencode({"chat_id": TG_CHAT_ID, "text": msg, "parse_mode": "HTML"}).encode()
        urllib.request.urlopen(url, data=data, timeout=5)
    except Exception as e:
        log(None, f"TG send error: {str(e)[:80]}")


# ============================================================
#  TG LOG — буфер логов
# ============================================================
_log_buffer = []
_log_lock   = threading.Lock()

def tg_log(acc_id: int, msg: str):
    line = f"[Акк {acc_id}] {msg}"
    with _log_lock:
        _log_buffer.append(line)
        if len(_log_buffer) > 100:
            _log_buffer.pop(0)
    tg(f"🖥 <b>Акк {acc_id}:</b> {msg}")


def tg_api(method: str, params: dict):
    for attempt in range(3):
        try:
            url  = f"https://api.telegram.org/bot{TG_TOKEN}/{method}"
            data = urllib.parse.urlencode(params).encode()
            resp = urllib.request.urlopen(url, data=data, timeout=5)
            return json.loads(resp.read().decode())
        except Exception as e:
            msg = str(e)
            if "429" in msg:
                time.sleep(2 * (attempt + 1))
                continue
            log(None, f"TG {method} error: {msg[:80]}")
            return {}
    return {}


def tg_send(msg: str, keyboard: str = None):
    params = {"chat_id": TG_CHAT_ID, "text": msg, "parse_mode": "HTML"}
    if keyboard:
        params["reply_markup"] = keyboard
    tg_api("sendMessage", params)


def tg_edit(message_id: int, msg: str, inline_keyboard: str = None):
    params = {"chat_id": TG_CHAT_ID, "message_id": message_id, "text": msg, "parse_mode": "HTML"}
    if inline_keyboard:
        params["reply_markup"] = inline_keyboard
    tg_api("editMessageText", params)


def tg_answer_callback(callback_id: str, text: str = ""):
    tg_api("answerCallbackQuery", {"callback_query_id": callback_id, "text": text})


def tg_get_updates(last_update_id: int):
    try:
        url  = f"https://api.telegram.org/bot{TG_TOKEN}/getUpdates?offset={last_update_id + 1}&timeout=10"
        resp = urllib.request.urlopen(url, timeout=15)
        data = json.loads(resp.read().decode())
        return data.get("result", [])
    except Exception as e:
        log(None, f"TG getUpdates error: {str(e)[:80]}")
        return []


# ============================================================
#  КЛАВИАТУРЫ
# ============================================================
def main_keyboard():
    return json.dumps({
        "keyboard": [
            [{"text": "📊 Статус"}, {"text": "🔄 Перезапуск браузеров"}],
            [{"text": "📋 Последние промо"}, {"text": "🌐 Страницы аккаунтов"}],
            [{"text": "⚙️ Режим работы"}, {"text": "🔛 Тумблер бота"}],
            [{"text": "💰 Балансы"}, {"text": "⚙️ Другие настройки"}]
        ],
        "resize_keyboard": True,
        "persistent": True
    })


def mode_keyboard(bot_mode: str):
    p = "✅ Пассивный"     if bot_mode == "passive"     else "Пассивный"
    m = "✅ По кнопке"     if bot_mode == "manual"      else "По кнопке"
    s = "✅ По стриму"     if bot_mode == "schedule"    else "По стриму 📡"
    i = "✅ По интеграции" if bot_mode == "integration" else "По интеграции 🔗"
    return json.dumps({"inline_keyboard": [
        [{"text": p, "callback_data": "mode_passive"},
         {"text": m, "callback_data": "mode_manual"}],
        [{"text": s, "callback_data": "mode_schedule"}],
        [{"text": i, "callback_data": "mode_integration"}],
    ]})


def tumbler_keyboard(browsers_on: bool):
    label = "⏹ Выключить" if browsers_on else "▶️ Включить"
    cb    = "tumbler_off"  if browsers_on else "tumbler_on"
    return json.dumps({"inline_keyboard": [[{"text": label, "callback_data": cb}]]})


def other_settings_keyboard(selenium_fallback: bool = True, shutdown_after_promo: bool = False):
    fb_label  = "🟢 Selenium fallback: ВКЛ" if selenium_fallback else "🔴 Selenium fallback: ВЫКЛ"
    sap_label = "🟢 Выкл. после промо: ВКЛ" if shutdown_after_promo else "🔴 Выкл. после промо: ВЫКЛ"
    return json.dumps({"inline_keyboard": [
        [{"text": "📺 Стримеры", "callback_data": "settings_channels"}],
        [{"text": fb_label,  "callback_data": "toggle_selenium_fallback"}],
        [{"text": sap_label, "callback_data": "toggle_shutdown_after_promo"}],
        [{"text": "🖥 Управление воркерами", "callback_data": "workers_panel"}],
    ]})


def workers_panel_keyboard():
    from distributor import WORKERS
    kb = []
    for w in WORKERS:
        kb.append([{"text": f"🖥 Воркер {w['id']}", "callback_data": f"worker_manage_{w['id']}"}])
    kb.append([{"text": "🔄 Перезапустить всех",  "callback_data": "workers_restart_all"}])
    kb.append([{"text": "🧪 Проверить всех",       "callback_data": "workers_test_all"}])
    return json.dumps({"inline_keyboard": kb})


def worker_manage_keyboard(worker_id: int):
    return json.dumps({"inline_keyboard": [
        [{"text": "🔄 Перезапустить браузер", "callback_data": f"worker_restart_{worker_id}"}],
        [{"text": "🧪 Тест активации",        "callback_data": f"worker_test_{worker_id}"}],
        [{"text": "📋 Логи",                   "callback_data": f"worker_logs_{worker_id}"}],
        [{"text": "◀️ Назад",                  "callback_data": "workers_panel"}],
    ]})


def channels_keyboard(channels_cfg: dict):
    """channels_cfg = {channel: filter_type}"""
    kb = []
    for ch, ft in channels_cfg.items():
        icon = "🔮" if ft == "emoji" else "⬜"
        kb.append([{"text": f"{icon} #{ch} [{ft}]", "callback_data": f"ch_manage_{ch}"}])
    kb.append([{"text": "➕ Добавить стримера", "callback_data": "add_channel"}])
    return json.dumps({"inline_keyboard": kb})


def channel_manage_keyboard(ch: str):
    """Подменю для конкретного канала."""
    return json.dumps({"inline_keyboard": [
        [{"text": "🔄 Сменить фильтр", "callback_data": f"ch_toggle_filter_{ch}"}],
        [{"text": "🗑 Удалить канал",   "callback_data": f"ch_delete_{ch}"}],
        [{"text": "◀️ Назад",            "callback_data": "settings_channels"}],
    ]})


def filter_choose_keyboard():
    """Выбор фильтра при добавлении стримера."""
    return json.dumps({"inline_keyboard": [
        [{"text": "🔮 Emoji (|| + эмодзи)", "callback_data": "ch_filter_emoji"}],
        [{"text": "⬜ Clean (01XXXX...)",    "callback_data": "ch_filter_clean"}],
    ]})


ALL_BUTTON_TEXTS = {
    "📊 Статус", "🔄 Перезапуск браузеров", "📋 Последние промо",
    "🌐 Страницы аккаунтов", "⚙️ Режим работы", "🔛 Тумблер бота",
    "💰 Балансы", "⚙️ Другие настройки",
}


# ============================================================
#  POLLING WORKER
# ============================================================
def tg_polling_worker(bot_state: dict):
    """
    bot_state — общий словарь состояния:
    {
      "bot_mode", "browsers_on",
      "channels", "waiting_for",
      "start_browsers_fn", "stop_browsers_fn", "restart_browsers_fn",
      "save_config_fn",
    }
    """
    last_update_id = 0
    log(None, "TG polling запущен...")
    time.sleep(2)

    mode = bot_state["bot_mode"]

    if mode == "schedule":
        mode_label = "По стриму 📡"
    elif mode == "passive":
        mode_label = "Пассивный 🟢"
    elif mode == "integration":
        mode_label = "По интеграции 🔗"
    else:
        mode_label = "По кнопке 🎛"

    from state import drivers
    tg_send(
        f"🟢 <b>Бот запущен</b>\n"
        f"👥 Аккаунтов: {len(drivers)}/{ACCOUNTS_COUNT}\n"
        f"📺 Каналы: {', '.join('#'+c for c in bot_state['channels'])}\n"
        f"⚙️ Режим: {mode_label}",
        main_keyboard()
    )

    while True:
        try:
            updates = tg_get_updates(last_update_id)
            for upd in updates:
                last_update_id = upd["update_id"]
                if "message" in upd:
                    msg     = upd["message"]
                    chat_id = str(msg.get("chat", {}).get("id", ""))
                    text    = msg.get("text", "").strip()
                    if chat_id == TG_CHAT_ID and text:
                        handle_command(text, bot_state)
                elif "callback_query" in upd:
                    cq      = upd["callback_query"]
                    chat_id = str(cq.get("message", {}).get("chat", {}).get("id", ""))
                    if chat_id == TG_CHAT_ID:
                        handle_callback(cq["id"], cq.get("data", ""), cq["message"]["message_id"], bot_state)
        except Exception as e:
            log(None, f"TG polling error: {str(e)[:80]}")
        time.sleep(0.8)


def _save(bot_state):
    bot_state["save_config_fn"]({
        "mode":              bot_state["bot_mode"],
        "browsers_on":       bot_state["browsers_on"],
        "channels":          bot_state["channels"] if isinstance(bot_state["channels"], dict) else {c: "emoji" for c in bot_state["channels"]},
        "selenium_fallback": bot_state.get("selenium_fallback", True),
    })


# ============================================================
#  КОМАНДЫ
# ============================================================
def handle_command(text: str, s: dict):
    from state import drivers, drivers_lock, promo_pool, used_promos, promo_pool_lock
    kb = main_keyboard()

    if text == "📊 Статус":
        from stream_checker import get_stream_status
        from distributor import get_workers_status
        import datetime
        with drivers_lock:
            count = len(drivers)
        now = datetime.datetime.utcnow() + datetime.timedelta(hours=3)
        mode_labels = {
            "passive":     "Пассивный 🟢",
            "manual":      f"По кнопке 🎛 ({'ВКЛ ✅' if s['browsers_on'] else 'ВЫКЛ ⏹'})",
            "schedule":    "По стриму 📡",
            "integration": "По интеграции 🔗",
        }
        # Статус стримеров
        stream_lines = []
        if s["bot_mode"] == "schedule":
            statuses = get_stream_status(s["channels"] if isinstance(s["channels"], dict) else {c: 'emoji' for c in s["channels"]})
            for ch, live in statuses.items():
                icon = "🔴 LIVE" if live else "⚫ офлайн"
                stream_lines.append(f"  #{ch}: {icon}")
        stream_info = "\n".join(stream_lines)

        # Статус воркеров — три состояния
        workers = get_workers_status()
        worker_lines = []
        workers_online = 0
        for w in workers:
            if not w["ok"]:
                # Воркер физически выключен
                worker_lines.append(f"  Акк {w['id']}: 🔴 недоступен")
            elif w.get("browser"):
                # Воркер работает + браузер активен
                worker_lines.append(f"  Акк {w['id']}: 🟢 онлайн")
                workers_online += 1
            else:
                # Воркер работает, но браузер выключен (нет стрима)
                worker_lines.append(f"  Акк {w['id']}: 🟡 оффлайн")
        workers_info = "\n".join(worker_lines)

        tg_send(
            f"📊 <b>Статус бота</b>\n"
            f"🕐 Время: {now.strftime('%H:%M:%S')}\n"
            f"👥 Аккаунтов онлайн: {workers_online}/{len(workers)}\n"
            f"📺 Каналы: {', '.join('#'+c for c in (s['channels'].keys() if isinstance(s['channels'], dict) else s['channels']))}\n"
            f"⚙️ Режим: {mode_labels.get(s['bot_mode'], s['bot_mode'])}\n"
            + (f"{stream_info}\n" if stream_info else "")
            + (f"{workers_info}\n" if workers_info else "") +
            f"🟢 Работает",
            kb
        )

    elif text == "🌐 Страницы аккаунтов":
        from state import drivers, drivers_lock
        with drivers_lock:
            current = list(drivers)
        lines = ["🌐 <b>Текущие страницы:</b>"]
        for i, d in enumerate(current, 1):
            try:
                short = d.current_url.replace("https://donatov.net", "")
                lines.append(f"Акк {i}: <code>{short}</code>")
            except Exception:
                lines.append(f"Акк {i}: недоступен")
        tg_send("\n".join(lines), kb)

    elif text == "📋 Последние промо":
        with promo_pool_lock:
            promos = list(promo_pool)
            used   = list(used_promos)
        if not promos:
            tg_send("📋 Промокодов ещё не было", kb)
        else:
            lines = ["📋 <b>Последняя раздача:</b>"]
            for p in promos:
                status = "✅" if p in used else "⏳"
                lines.append(f"{status} <code>{p}</code>")
            tg_send("\n".join(lines), kb)

    elif text == "🔄 Перезапуск браузеров":
        tg_send("🔄 Перезапускаю браузеры...", kb)
        threading.Thread(target=s["restart_browsers_fn"], daemon=True).start()

    elif text == "⚙️ Режим работы":
        mode_labels = {"passive": "Пассивный", "manual": "По кнопке", "schedule": "По расписанию"}
        tg_send(
            f"⚙️ <b>Режим работы</b>\nТекущий режим: <b>{mode_labels.get(s['bot_mode'], s['bot_mode'])}</b>\n\nВыберите режим:",
            mode_keyboard(s["bot_mode"])
        )

    elif text == "🔛 Тумблер бота":
        if s["bot_mode"] != "manual":
            tg_send("⚠️ Переключитесь в режим <b>«По кнопке»</b> чтобы использовать тумблер", kb)
        else:
            status_label = "Включён ✅" if s["browsers_on"] else "Выключен ⏹"
            tg_send(f"🔛 <b>Тумблер бота</b>\nТекущий статус: <b>{status_label}</b>", tumbler_keyboard(s["browsers_on"]))

    elif text == "💰 Балансы":
        tg_send("💰 Проверяю балансы...", kb)
        threading.Thread(target=check_balances, daemon=True).start()

    elif text == "⚙️ Другие настройки":
        tg_send("Выберите что именно хотите настроить:", other_settings_keyboard(s.get("selenium_fallback", True), s.get("integration_shutdown_after_promo", False)))

    elif s["waiting_for"] is not None and text not in ALL_BUTTON_TEXTS:
        handle_waiting_input(text, s)

    else:
        tg_send("👋 Используй кнопки ниже", kb)


def handle_waiting_input(text: str, s: dict):
    if s["waiting_for"] == "add_channel":
        ch_cfg   = s["channels"] if isinstance(s["channels"], dict) else {}
        channels = [c.strip().lstrip("@").lower() for c in text.split(",") if c.strip()]
        new_chs  = [c for c in channels if c not in ch_cfg]
        if not new_chs:
            s["waiting_for"] = None
            tg_send("⚠️ Все каналы уже добавлены", main_keyboard())
            return
        if len(new_chs) == 1:
            # Один канал — спрашиваем фильтр
            s["_pending_channel"] = new_chs[0]
            s["waiting_for"] = None
            tg_send(f"Выберите фильтр для #{new_chs[0]}:", filter_choose_keyboard())
        else:
            # Несколько — добавляем все с emoji по умолчанию, потом можно сменить
            from state import irc_join_queue
            for ch in new_chs:
                ch_cfg[ch] = "emoji"
                irc_join_queue.put(ch)
            s["channels"] = ch_cfg
            s["waiting_for"] = None
            _save(s)
            tg_send(f"✅ Добавлено с фильтром 🔮 emoji: {', '.join(new_chs)}\nСмени фильтр через ⚙️ Другие настройки → Стримеры", main_keyboard())




# ============================================================
#  CALLBACKS
# ============================================================
def handle_callback(callback_id: str, data: str, message_id: int, s: dict):
    if data == "mode_passive":
        from state import drivers
        s["bot_mode"] = "passive"
        s["browsers_on"] = True
        _save(s)
        tg_answer_callback(callback_id, "Режим: Пассивный")
        tg_edit(message_id, "⚙️ <b>Режим работы</b>\nТекущий режим: <b>Пассивный 🟢</b>\n\nВыберите режим:", mode_keyboard(s["bot_mode"]))
        tg_send("🟢 Режим: <b>Пассивный</b> — браузеры всегда включены", main_keyboard())
        if len(drivers) < ACCOUNTS_COUNT:
            threading.Thread(target=s["start_browsers_fn"], daemon=True).start()

    elif data == "mode_manual":
        from state import drivers
        s["bot_mode"] = "manual"
        # Синхронизируем browsers_on с реальным состоянием браузеров
        s["browsers_on"] = len(drivers) > 0
        _save(s)
        tg_answer_callback(callback_id, "Режим: По кнопке")
        tg_edit(message_id, "⚙️ <b>Режим работы</b>\nТекущий режим: <b>По кнопке 🎛</b>\n\nВыберите режим:", mode_keyboard(s["bot_mode"]))
        status = "ВКЛ ✅" if s["browsers_on"] else "ВЫКЛ ⏹"
        tg_send(f"🎛 Режим: <b>По кнопке</b> — браузеры сейчас {status}", main_keyboard())

    elif data == "mode_schedule":
        from stream_checker import is_stream_live, set_known_state
        from state import drivers
        s["bot_mode"] = "schedule"
        _save(s)
        tg_answer_callback(callback_id, "Режим: По стриму")
        tg_edit(message_id, "⚙️ <b>Режим работы</b>\nТекущий режим: <b>По стриму 📡</b>\n\nВыберите режим:", mode_keyboard(s["bot_mode"]))
        channels = list(s.get("channels", {"t2x2": "emoji"}).keys()) if isinstance(s.get("channels"), dict) else s.get("channels", ["t2x2"])
        live = any(is_stream_live(ch) for ch in channels)
        if live:
            tg_send("📡 Режим: <b>По стриму</b>\n🔴 Стрим онлайн — запускаю браузеры", main_keyboard())
            set_known_state(True)  # синхронизируем stream_worker чтобы не запустил повторно
            if len(drivers) < ACCOUNTS_COUNT:
                threading.Thread(target=s["start_browsers_fn"], daemon=True).start()
        else:
            tg_send("📡 Режим: <b>По стриму</b>\n⚫ Стрим офлайн — жду начала стрима", main_keyboard())
            set_known_state(False)  # синхронизируем stream_worker
            if len(drivers) > 0:
                threading.Thread(target=s["stop_browsers_fn"], daemon=True).start()

    elif data == "mode_integration":
        from state import drivers
        s["bot_mode"] = "integration"
        _save(s)
        tg_answer_callback(callback_id, "Режим: По интеграции")
        tg_edit(message_id, "⚙️ <b>Режим работы</b>\nТекущий режим: <b>По интеграции 🔗</b>\n\nВыберите режим:", mode_keyboard(s["bot_mode"]))
        tg_send("🔗 Режим: <b>По интеграции</b>\n⚫ Жду donatov.net в чате — браузеры запустятся автоматически", main_keyboard())
        # Останавливаем браузеры если были запущены
        if len(drivers) > 0:
            threading.Thread(target=s["stop_browsers_fn"], daemon=True).start()

    elif data == "tumbler_on":
        if s["bot_mode"] != "manual":
            tg_answer_callback(callback_id, "Переключитесь в режим По кнопке")
            return
        s["browsers_on"] = True
        _save(s)
        tg_answer_callback(callback_id, "Запускаю...")
        tg_edit(message_id, "🔛 <b>Тумблер бота</b>\nТекущий статус: <b>Включён ✅</b>", tumbler_keyboard(s["browsers_on"]))
        threading.Thread(target=s["start_browsers_fn"], daemon=True).start()

    elif data == "tumbler_off":
        if s["bot_mode"] != "manual":
            tg_answer_callback(callback_id, "Переключитесь в режим По кнопке")
            return
        s["browsers_on"] = False
        _save(s)
        tg_answer_callback(callback_id, "Выключаю...")
        tg_edit(message_id, "🔛 <b>Тумблер бота</b>\nТекущий статус: <b>Выключен ⏹</b>", tumbler_keyboard(s["browsers_on"]))
        threading.Thread(target=s["stop_browsers_fn"], daemon=True).start()

    elif data == "settings_channels":
        tg_answer_callback(callback_id, "")
        ch_cfg = s["channels"] if isinstance(s["channels"], dict) else {c: "emoji" for c in s["channels"]}
        lines  = ["📺 <b>Стримеры</b>\n"]
        for ch, ft in ch_cfg.items():
            icon = "🔮" if ft == "emoji" else "⬜"
            lines.append(f"{icon} #{ch} — фильтр: <b>{ft}</b>")
        lines.append("\nНажми на канал для управления:")
        tg_send("\n".join(lines), channels_keyboard(ch_cfg))

    elif data.startswith("ch_manage_"):
        ch = data.replace("ch_manage_", "")
        tg_answer_callback(callback_id, "")
        ch_cfg = s["channels"] if isinstance(s["channels"], dict) else {}
        ft     = ch_cfg.get(ch, "emoji")
        icon   = "🔮" if ft == "emoji" else "⬜"
        tg_send(f"📺 Канал <b>#{ch}</b>\nФильтр: {icon} <b>{ft}</b>\n\nЧто сделать?", channel_manage_keyboard(ch))

    elif data.startswith("ch_toggle_filter_"):
        ch  = data.replace("ch_toggle_filter_", "")
        tg_answer_callback(callback_id, "")
        ch_cfg = s["channels"] if isinstance(s["channels"], dict) else {}
        old_ft = ch_cfg.get(ch, "emoji")
        new_ft = "clean" if old_ft == "emoji" else "emoji"
        ch_cfg[ch]   = new_ft
        s["channels"] = ch_cfg
        _save(s)
        icon = "🔮" if new_ft == "emoji" else "⬜"
        tg_send(f"✅ #{ch} → фильтр изменён на {icon} <b>{new_ft}</b>", channels_keyboard(ch_cfg))

    elif data.startswith("ch_delete_"):
        ch = data.replace("ch_delete_", "")
        ch_cfg = s["channels"] if isinstance(s["channels"], dict) else {}
        if ch in ch_cfg and len(ch_cfg) > 1:
            del ch_cfg[ch]
            s["channels"] = ch_cfg
            _save(s)
            tg_answer_callback(callback_id, f"Удалён: {ch}")
            tg_send(f"✅ Удалён: #{ch}\nОсталось: {', '.join(ch_cfg.keys())}", main_keyboard())
        elif len(ch_cfg) <= 1:
            tg_answer_callback(callback_id, "Нельзя удалить последний канал")
        else:
            tg_answer_callback(callback_id, "Канал не найден")

    elif data == "ch_filter_emoji":
        new_ch = s.get("_pending_channel", "")
        if new_ch:
            ch_cfg = s["channels"] if isinstance(s["channels"], dict) else {}
            ch_cfg[new_ch] = "emoji"
            s["channels"] = ch_cfg
            s.pop("_pending_channel", None)
            _save(s)
            from state import irc_join_queue
            irc_join_queue.put(new_ch)
            tg_answer_callback(callback_id, "")
            tg_send(f"✅ Добавлен: #{new_ch} [🔮 emoji]\nВсе каналы: {', '.join(ch_cfg.keys())}", main_keyboard())

    elif data == "ch_filter_clean":
        new_ch = s.get("_pending_channel", "")
        if new_ch:
            ch_cfg = s["channels"] if isinstance(s["channels"], dict) else {}
            ch_cfg[new_ch] = "clean"
            s["channels"] = ch_cfg
            s.pop("_pending_channel", None)
            _save(s)
            from state import irc_join_queue
            irc_join_queue.put(new_ch)
            tg_answer_callback(callback_id, "")
            tg_send(f"✅ Добавлен: #{new_ch} [⬜ clean]\nВсе каналы: {', '.join(ch_cfg.keys())}", main_keyboard())

    elif data == "add_channel":
        s["waiting_for"] = "add_channel"
        tg_answer_callback(callback_id, "")
        tg_send("Введи ник(и) стримера через запятую, например:\nvasyapui, gsdgu1, aaa")

    elif data == "toggle_selenium_fallback":
        current = s.get("selenium_fallback", True)
        s["selenium_fallback"] = not current
        _save(s)
        tg_answer_callback(callback_id, "")
        state_label = "ВКЛ 🟢" if s["selenium_fallback"] else "ВЫКЛ 🔴"
        tg_edit(message_id,
            f"⚙️ <b>Другие настройки</b>\n\n"
            f"Selenium fallback: <b>{state_label}</b>\n"
            f"{'Если HTTP не сработает — будет попытка через браузер' if s['selenium_fallback'] else '⚠️ Только HTTP. Если не сработает — промо пропадёт'}",
            other_settings_keyboard(s["selenium_fallback"], s.get("integration_shutdown_after_promo", False))
        )

    elif data == "toggle_shutdown_after_promo":
        current = s.get("integration_shutdown_after_promo", False)
        s["integration_shutdown_after_promo"] = not current
        _save(s)
        tg_answer_callback(callback_id, "")
        state_label = "ВКЛ 🟢" if s["integration_shutdown_after_promo"] else "ВЫКЛ 🔴"
        tg_edit(message_id,
            f"⚙️ <b>Другие настройки</b>\n\n"
            f"Выкл. после промо: <b>{state_label}</b>\n"
            f"{'15 мин после donatov.net, 5 мин после первых промо' if s['integration_shutdown_after_promo'] else 'Выключение по статусу стрима (стандартно)'}",
            other_settings_keyboard(s.get("selenium_fallback", True), s["integration_shutdown_after_promo"])
        )

    elif data == "workers_panel":
        from distributor import get_workers_status
        tg_answer_callback(callback_id, "")
        workers = get_workers_status()
        lines = ["🖥 <b>Воркеры</b>\n"]
        for w in workers:
            if w["ok"]:
                icon = "🟢" if w.get("browser") else "🟡"
                url  = w.get("url", "")
                lines.append(f"{icon} Воркер {w['id']} — онлайн\n   {url}")
            else:
                lines.append(f"🔴 Воркер {w['id']} — недоступен")
        tg_send("\n".join(lines), workers_panel_keyboard())

    elif data.startswith("worker_manage_"):
        worker_id = int(data.replace("worker_manage_", ""))
        from distributor import get_workers_status, WORKERS
        tg_answer_callback(callback_id, "")
        workers = get_workers_status()
        w = next((x for x in workers if x["id"] == worker_id), None)
        if w and w["ok"]:
            icon = "🟢" if w.get("browser") else "🟡"
            tg_send(
                f"🖥 <b>Воркер {worker_id}</b>\n"
                f"Статус: {icon} онлайн\n"
                f"URL: {w.get('url', '?')}",
                worker_manage_keyboard(worker_id)
            )
        else:
            tg_send(f"🔴 <b>Воркер {worker_id}</b> недоступен", worker_manage_keyboard(worker_id))

    elif data.startswith("worker_restart_"):
        worker_id = int(data.replace("worker_restart_", ""))
        from distributor import WORKERS
        tg_answer_callback(callback_id, "Перезапускаю...")
        w = next((x for x in WORKERS if x["id"] == worker_id), None)
        if w:
            def _restart(url=w["url"]):
                try:
                    import urllib.request, json as _json
                    body = _json.dumps({}).encode()
                    req  = urllib.request.Request(
                        f"{url}/restart_browser",
                        data=body,
                        headers={"Content-Type": "application/json", "X-Worker-Secret": "secret123"},
                        method="POST"
                    )
                    urllib.request.urlopen(req, timeout=30)
                    tg(f"✅ Воркер {worker_id} — браузер перезапущен")
                except Exception as e:
                    tg(f"❌ Воркер {worker_id} — ошибка перезапуска: {str(e)[:80]}")
            threading.Thread(target=_restart, daemon=True).start()
            tg_send(f"🔄 Воркер {worker_id} — перезапускаю браузер...")

    elif data.startswith("worker_logs_"):
        worker_id = int(data.replace("worker_logs_", ""))
        from distributor import WORKERS
        tg_answer_callback(callback_id, "")
        w = next((x for x in WORKERS if x["id"] == worker_id), None)
        if w:
            try:
                import urllib.request as _ur
                req  = _ur.Request(
                    f"{w['url']}/logs",
                    headers={"X-Worker-Secret": "secret123"}
                )
                resp = _ur.urlopen(req, timeout=5)
                data_logs = json.loads(resp.read().decode())
                lines = data_logs.get("logs", [])[-20:]  # последние 20 строк
                tg_send(f"📋 <b>Логи воркера {worker_id}</b>\n\n<code>" + "\n".join(lines) + "</code>")
            except Exception as e:
                tg_send(f"❌ Не удалось получить логи воркера {worker_id}: {str(e)[:80]}")

    elif data.startswith("worker_test_"):
        worker_id = int(data.replace("worker_test_", ""))
        from distributor import WORKERS
        tg_answer_callback(callback_id, "Тестирую...")
        w = next((x for x in WORKERS if x["id"] == worker_id), None)
        if not w:
            tg_send(f"❌ Воркер {worker_id} не найден")
        else:
            def _test(ww=w, wid=worker_id):
                try:
                    req  = urllib.request.Request(
                        f"{ww['url']}/test_activate",
                        data=b"{}",
                        headers={"Content-Type": "application/json", "X-Worker-Secret": WORKER_SECRET},
                        method="POST"
                    )
                    resp = urllib.request.urlopen(req, timeout=30)
                    r    = json.loads(resp.read().decode())
                    ok   = r.get("ok", False)
                    elapsed = r.get("elapsed", "?")
                    status  = r.get("status_code", "?")
                    msg     = r.get("message", "")[:80]
                    icon = "✅" if ok else "❌"
                    tg(f"{icon} <b>Воркер {wid} — тест активации</b>\n"
                       f"Статус: {status}\n"
                       f"Время: {elapsed}с\n"
                       f"Ответ: {msg}")
                except Exception as e:
                    tg(f"❌ <b>Воркер {wid}</b> не отвечает: {str(e)[:80]}")
            threading.Thread(target=_test, daemon=True).start()
            tg_send(f"🧪 Тестирую воркер {worker_id}...")

    elif data == "workers_test_all":
        from distributor import WORKERS
        tg_answer_callback(callback_id, "Тестирую всех...")
        def _test_all():
            lines = ["🧪 <b>Результаты теста всех воркеров:</b>\n"]
            for w in WORKERS:
                try:
                    req  = urllib.request.Request(
                        f"{w['url']}/test_activate",
                        data=b"{}",
                        headers={"Content-Type": "application/json", "X-Worker-Secret": WORKER_SECRET},
                        method="POST"
                    )
                    resp = urllib.request.urlopen(req, timeout=30)
                    r    = json.loads(resp.read().decode())
                    ok      = r.get("ok", False)
                    elapsed = r.get("elapsed", "?")
                    status  = r.get("status_code", "?")
                    icon = "✅" if ok else "❌"
                    lines.append(f"{icon} Воркер {w['id']}: {status} за {elapsed}с")
                except Exception as e:
                    lines.append(f"❌ Воркер {w['id']}: не отвечает")
            tg("\n".join(lines))
        threading.Thread(target=_test_all, daemon=True).start()
        tg_send("🧪 Тестирую все воркеры, подожди...")

    elif data == "workers_restart_all":
        from distributor import WORKERS
        tg_answer_callback(callback_id, "Перезапускаю всех...")
        def _restart_all():
            for w in WORKERS:
                try:
                    import urllib.request as _ur, json as _json
                    body = _json.dumps({}).encode()
                    req  = _ur.Request(
                        f"{w['url']}/restart_browser",
                        data=body,
                        headers={"Content-Type": "application/json", "X-Worker-Secret": "secret123"},
                        method="POST"
                    )
                    _ur.urlopen(req, timeout=30)
                    tg(f"✅ Воркер {w['id']} перезапущен")
                except Exception as e:
                    tg(f"❌ Воркер {w['id']} ошибка: {str(e)[:60]}")
        threading.Thread(target=_restart_all, daemon=True).start()
        tg_send("🔄 Перезапускаю браузеры на всех воркерах...")




def check_balances():
    from distributor import WORKERS
    results = {}
    lock = threading.Lock()

    def fetch(w):
        try:
            req  = urllib.request.Request(
                f"{w['url']}/balance",
                headers={"X-Worker-Secret": "secret123"},
            )
            resp = urllib.request.urlopen(req, timeout=15)
            r    = json.loads(resp.read().decode())
            if r.get("ok"):
                email   = r.get("email", f"Акк {w['id']}")
                balance = r.get("balance", "?")
                with lock:
                    results[w["id"]] = f"{email} — <b>{balance}</b> руб"
            else:
                with lock:
                    results[w["id"]] = f"Акк {w['id']} — ошибка браузера"
        except Exception as e:
            with lock:
                results[w["id"]] = f"Акк {w['id']} — недоступен"

    threads = [threading.Thread(target=fetch, args=(w,), daemon=True) for w in WORKERS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=20)

    lines = ["💰 <b>БАЛАНСЫ</b>\n"]
    for i in sorted(results):
        lines.append(results[i])
    tg_send("\n".join(lines), main_keyboard())
