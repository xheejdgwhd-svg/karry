# ============================================================
#  АКТИВАЦИЯ ПРОМОКОДА
# ============================================================
import time
import threading
import os
import json

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

from http_activator import activate_http
from config import (
    INPUT_SELECTOR, TARGET_URL, MAX_RETRIES,
    SEL_ZABRATY, SEL_ACTIVATE
)
from logger import log
from queue   import Queue
from state  import (
    promo_pool, used_promos, promo_pool_lock,
    distribute_lock, drivers, drivers_lock
)

# ============================================================
#  ДАМПЕР СЕТЕВЫХ ЗАПРОСОВ
# ============================================================
DUMP_DIR = "/home/xheejdgwhd/bot/dump_data"

# ============================================================
#  TG ОЧЕРЕДЬ — неблокирующая отправка
# ============================================================
_tg_queue = Queue()

def _tg_worker():
    while True:
        msg = _tg_queue.get()
        try:
            from telegram_bot import tg as _tg
            _tg(msg)
        except Exception:
            pass
        _tg_queue.task_done()

import threading as _threading
_threading.Thread(target=_tg_worker, daemon=True, name="TGQueue").start()

def tg_async(msg: str):
    """Неблокирующая отправка TG — не тормозит активацию."""
    _tg_queue.put(msg)

# ============================================================
#  ДАМПЕР СЕТЕВЫХ ЗАПРОСОВ
# ============================================================
DUMP_DIR = "/home/xheejdgwhd/bot/dump_data"

def enable_network_dump(driver, acc_id: int):
    """Включает перехват сетевых запросов через CDP."""
    try:
        driver.execute_cdp_cmd("Network.enable", {
            "maxResourceBufferSize": 10 * 1024 * 1024,
            "maxTotalBufferSize":    30 * 1024 * 1024,
        })
    except Exception as e:
        log(acc_id, f"[DUMP] Ошибка включения Network: {e}")


def dump_http(acc_id: int, phase: str, records: list):
    """
    Сохраняет записи HTTP активации (из http_activator).
    records = [{"url", "req_body", "resp_status", "resp_body"}, ...]
    """
    try:
        os.makedirs(DUMP_DIR, exist_ok=True)
        ts   = time.strftime("%Y%m%d_%H%M%S")
        path = os.path.join(DUMP_DIR, f"acc{acc_id}_{phase}_{ts}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
        log(acc_id, f"[DUMP] HTTP {len(records)} запросов → {path}")
    except Exception as e:
        log(acc_id, f"[DUMP] Ошибка dump_http: {e}")


def dump_selenium(driver, acc_id: int, phase: str):
    """
    Сохраняет запросы + тела ответов из Selenium CDP.
    Вызывать сразу после каждого действия пока буфер ещё живой.
    """
    try:
        os.makedirs(DUMP_DIR, exist_ok=True)
        logs = driver.get_log("performance")

        req_map  = {}
        resp_map = {}

        for entry in logs:
            try:
                msg    = json.loads(entry["message"])["message"]
                method = msg.get("method", "")
                params = msg.get("params", {})
                rid    = params.get("requestId")

                if method == "Network.requestWillBeSent":
                    req = params.get("request", {})
                    url = req.get("url", "")
                    if "donatov.net" not in url:
                        continue
                    req_map[rid] = {
                        "url":    url,
                        "method": req.get("method", ""),
                        "body":   req.get("postData", ""),
                    }

                elif method == "Network.responseReceived":
                    resp = params.get("response", {})
                    if rid not in req_map:
                        continue
                    resp_map[rid] = {"status": resp.get("status")}

            except Exception:
                pass

        # Сразу пытаемся вытащить тела ответов
        records = []
        for rid, req in req_map.items():
            resp_body = None
            try:
                b = driver.execute_cdp_cmd("Network.getResponseBody", {"requestId": rid})
                resp_body = b.get("body", "")
                try:    resp_body = json.loads(resp_body)
                except: pass
            except Exception:
                pass

            req_body = req["body"]
            try:    req_body = json.loads(req_body)
            except: pass

            records.append({
                "url":         req["url"],
                "method":      req["method"],
                "req_body":    req_body or None,
                "resp_status": resp_map.get(rid, {}).get("status"),
                "resp_body":   resp_body,
            })

        if records:
            ts   = time.strftime("%Y%m%d_%H%M%S")
            path = os.path.join(DUMP_DIR, f"acc{acc_id}_{phase}_{ts}.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(records, f, ensure_ascii=False, indent=2)
            with_body = sum(1 for r in records if r["resp_body"] is not None)
            log(acc_id, f"[DUMP] Selenium {len(records)} запросов ({with_body} с телом) → {path}")
        else:
            log(acc_id, f"[DUMP] Нет запросов к donatov.net")

    except Exception as e:
        log(acc_id, f"[DUMP] Ошибка dump_selenium: {e}")


# ============================================================
#  ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================
def type_code(driver, code: str):
    input_field = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, INPUT_SELECTOR))
    )
    # Быстрый ввод — весь код сразу
    result = driver.execute_script("""
        var el  = arguments[0];
        var val = arguments[1];
        var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        el.focus();
        el.dispatchEvent(new FocusEvent('focus', { bubbles: true }));
        setter.call(el, val);
        el.dispatchEvent(new Event('input',  { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
        return el.value;
    """, input_field, code)

    # Fallback — посимвольный если быстрый не сработал
    if result != code:
        driver.execute_script("""
            var el  = arguments[0];
            var val = arguments[1];
            var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            el.focus();
            el.dispatchEvent(new FocusEvent('focus',   { bubbles: true }));
            el.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
            el.dispatchEvent(new MouseEvent('click',   { bubbles: true }));
            setter.call(el, '');
            el.dispatchEvent(new Event('input', { bubbles: true }));
            for (var i = 0; i < val.length; i++) {
                var ch   = val[i];
                var opts = { key: ch, code: 'Key' + ch, bubbles: true, cancelable: true };
                el.dispatchEvent(new KeyboardEvent('keydown',  opts));
                el.dispatchEvent(new KeyboardEvent('keypress', opts));
                setter.call(el, val.substring(0, i + 1));
                el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ch }));
                el.dispatchEvent(new KeyboardEvent('keyup', opts));
            }
            el.dispatchEvent(new Event('change',       { bubbles: true }));
            el.dispatchEvent(new FocusEvent('blur',     { bubbles: true }));
            el.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
        """, input_field, code)


def click_css(driver, selector: str, timeout: int = 8) -> bool:
    try:
        el = WebDriverWait(driver, timeout).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
        )
        el.click()
        return True
    except TimeoutException:
        return False


def click_by_text(driver, text: str, timeout: int = 8) -> bool:
    try:
        btn = WebDriverWait(driver, timeout).until(
            EC.element_to_be_clickable((By.XPATH, f"//*[contains(text(), '{text}')]"))
        )
        btn.click()
        return True
    except TimeoutException:
        return False


def dismiss_popup(driver, timeout: int = 4):
    try:
        WebDriverWait(driver, timeout).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, '.swal2-popup'))
        )
        title = driver.execute_script(
            "return (document.querySelector('.swal2-title') || {}).innerText || '';"
        )
        body = driver.execute_script(
            "return (document.querySelector('#swal2-html-container') || {}).innerText || '';"
        )
        text = (title + ' ' + body).strip()
        for sel in ['.swal2-confirm', '.swal2-cancel', '.swal2-deny']:
            btn = driver.execute_script(f"return document.querySelector('{sel}');")
            if btn:
                btn.click()
                break
        return text or "popup"
    except TimeoutException:
        return None


def go_to_activate(driver, wait: WebDriverWait):
    if "activate" not in driver.current_url:
        driver.get(TARGET_URL)
    wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, INPUT_SELECTOR)))


def claim_next_promo(exclude: set):
    with promo_pool_lock:
        for p in promo_pool:
            if p not in exclude and p not in used_promos:
                used_promos.add(p)
                return p
    return None


# ============================================================
#  АКТИВАЦИЯ
# ============================================================
def activate_code(driver, initial_code: str, acc_id: int, t_distribute: float = None):
    """
    HTTP + Selenium параллельно при техническом фейле HTTP.
    - HTTP 200 успех → готово
    - HTTP 400/404 → пропуск
    - HTTP технический фейл → немедленно Selenium без ожидания
    """
    from config import load_config
    t_start = time.time()
    if t_distribute:
        log(acc_id, f"⏱ distribute→activate: {round(t_start - t_distribute, 3)}с")

    selenium_fallback = load_config().get("selenium_fallback", True)

    # ── HTTP путь ────────────────────────────────────────
    result = activate_http(driver, acc_id, initial_code)

    if result["success"]:
        elapsed = result["elapsed"]
        log(acc_id, f"✅ HTTP УСПЕХ за {elapsed}с | {initial_code}")
        tg_async(f"✅ <b>УСПЕХ! Акк {acc_id}</b> (HTTP 🚀)\n🎟 Код: <code>{initial_code}</code>\n⏱ {elapsed}с")
        threading.Thread(
            target=dump_http,
            args=(acc_id, "http_success", result.get("dump_records", [])),
            daemon=True
        ).start()
        def _return(d=driver, aid=acc_id):
            time.sleep(60)
            try: d.get(TARGET_URL)
            except: pass
        threading.Thread(target=_return, daemon=True).start()
        return

    msg         = result["message"].lower()
    status_code = result.get("status_code", 0)

    # 400 — мусорный код
    if status_code == 400 or "invalid" in msg:
        log(acc_id, f"HTTP 400: мусорный код {initial_code} — пропуск")
        tg_async(f"🚫 <b>Акк {acc_id}</b>: код невалиден <code>{initial_code}</code>")
        return

    # 404 — код не найден
    if status_code == 404 or any(w in msg for w in ["не найден", "not found", "недоступен", "already", "активирован ранее"]):
        log(acc_id, f"HTTP 404: код не найден {initial_code} — берём следующий")
        tg_async(f"⚠️ <b>Акк {acc_id}</b>: не найден <code>{initial_code}</code>")
        next_code = claim_next_promo({initial_code})
        if next_code:
            result2 = activate_http(driver, acc_id, next_code)
            if result2["success"]:
                elapsed = result2["elapsed"]
                log(acc_id, f"✅ HTTP УСПЕХ (2й код) за {elapsed}с | {next_code}")
                tg_async(f"✅ <b>УСПЕХ! Акк {acc_id}</b> (HTTP 🚀)\n🎟 Код: <code>{next_code}</code>\n⏱ {elapsed}с")
                def _return2(d=driver, aid=acc_id):
                    time.sleep(60)
                    try: d.get(TARGET_URL)
                    except: pass
                threading.Thread(target=_return2, daemon=True).start()
                return
        log(acc_id, "HTTP: нет доступных кодов")
        return

    # Технический фейл — немедленно Selenium без задержки
    log(acc_id, f"HTTP технический фейл ({status_code}) → немедленно Selenium")
    if not selenium_fallback:
        log(acc_id, "Selenium fallback ВЫКЛ — пропускаем")
        tg_async(f"❌ <b>Акк {acc_id}</b>: HTTP failed, fallback выкл")
        return

    ok = _activate_selenium(driver, initial_code, acc_id, t_start, t_distribute)
    if not ok:
        log(acc_id, f"❌ Selenium fallback не помог: {initial_code}")


# Ключевые слова успешной активации в попапе
_SUCCESS_KW = ['получил', 'успешно', 'активирован', 'зачислен', 'добавлен', 'забрал', 'success']
# Ключевые слова ошибки в попапе
_FAIL_KW    = ['не найден', 'не существует', 'invalid', 'not found', 'неверн', 'ошибка', 'error',
                'уже использован', 'уже активирован', 'недоступен', 'истёк', 'expired']


def _activate_selenium(driver, initial_code: str, acc_id: int, t_start: float = None, t_distribute: float = None) -> bool:
    """
    Оптимизированный Selenium активатор. Цель: 4-7 сек.
    Возвращает True при успехе, False при неудаче.
    """
    if t_start is None:
        t_start = time.time()

    wait = WebDriverWait(driver, 4)
    tried = {initial_code}
    code  = initial_code

    enable_network_dump(driver, acc_id)

    if t_distribute:
        log(acc_id, f"⏱ distribute→activate (sel): {round(t_start - t_distribute, 3)}с")

    for attempt in range(1, MAX_RETRIES + 1):
        log(acc_id, f"── Selenium попытка {attempt}/{MAX_RETRIES} | {code}")

        try:
            # Страница активации
            if "activate" not in driver.current_url:
                driver.get(TARGET_URL)
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, INPUT_SELECTOR)))

            # Ввод кода
            type_code(driver, code)

            # Клик Продолжить — JS быстрее чем WebDriverWait
            clicked = driver.execute_script("""
                var btn = document.querySelector('button.btn-primary');
                if (!btn) {
                    var els = document.querySelectorAll('button');
                    for (var e of els) {
                        if (e.innerText && e.innerText.includes('Продолжить')) { btn = e; break; }
                    }
                }
                if (btn) { btn.click(); return true; }
                return false;
            """)
            if not clicked:
                log(acc_id, "⚠️ Продолжить не найдена")
                continue
            log(acc_id, "Продолжить ✓")

            # Дамп в фоне — не блокируем
            threading.Thread(target=dump_selenium, args=(driver, acc_id, "after_continue"), daemon=True).start()

            # Попап после "Продолжить" — мог появиться если код не найден
            popup_text = dismiss_popup(driver, timeout=0.8)
            if popup_text:
                lower = popup_text.lower()
                log(acc_id, f"Попап после Продолжить: '{popup_text}'")
                if any(kw in lower for kw in _FAIL_KW):
                    log(acc_id, f"❌ Код не найден: {code}")
                    tg_async(f"❌ <b>Акк {acc_id}</b>: не найден <code>{code}</code>")
                    next_code = claim_next_promo(tried)
                    if next_code:
                        tried.add(next_code)
                        code = next_code
                        continue
                    else:
                        break
                # Любой другой попап — логируем и продолжаем

            # Ждём страницу выбора
            try:
                WebDriverWait(driver, 2.5).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, SEL_ZABRATY))
                )
            except TimeoutException:
                log(acc_id, "⚠️ Страница выбора не появилась")
                continue

            # JS клик Забрать себе
            driver.execute_script(f"""
                var el = document.querySelector('{SEL_ZABRATY}');
                if (el) el.click();
            """)
            log(acc_id, "Забрать себе ✓")

            # JS клик Активировать (до 2 попыток если попап с ошибкой)
            activated = False
            for activate_attempt in range(2):
                try:
                    WebDriverWait(driver, 2).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, SEL_ACTIVATE))
                    )
                except TimeoutException:
                    log(acc_id, "⚠️ Кнопка Активировать не появилась")
                    break

                driver.execute_script(f"""
                    var el = document.querySelector('{SEL_ACTIVATE}');
                    if (el) el.click();
                """)
                log(acc_id, f"Активировать ✓ (попытка {activate_attempt+1})")

                # Дамп в фоне
                threading.Thread(target=dump_selenium, args=(driver, acc_id, "after_activate"), daemon=True).start()

                # Ждём попап — увеличен до 2с чтобы не пропустить ответ сервера
                err_popup = dismiss_popup(driver, timeout=2.0)
                if err_popup:
                    lower_ep = err_popup.lower()
                    log(acc_id, f"Попап после Активировать: '{err_popup}'")

                    # Проверяем успех первым — некоторые сайты показывают успех как попап
                    if any(kw in lower_ep for kw in _SUCCESS_KW):
                        elapsed = round(time.time() - t_start, 1)
                        log(acc_id, f"✅ Selenium УСПЕХ (попап) за {elapsed}с | {code}")
                        tg_async(f"✅ <b>УСПЕХ! Акк {acc_id}</b> (Selenium)\n🎟 Код: <code>{code}</code>\n⏱ {elapsed}с")
                        activated = True
                        break

                    # Ошибка — повтор клика Забрать/Активировать
                    if any(kw in lower_ep for kw in _FAIL_KW):
                        log(acc_id, f"⚠️ Ошибка активации: {err_popup} — повтор")
                        tg_async(f"⚠️ <b>Акк {acc_id}</b>: {err_popup}")
                        driver.execute_script(f"var el=document.querySelector('{SEL_ZABRATY}'); if(el) el.click();")
                        continue

                    # Неизвестный попап — логируем, считаем ошибкой
                    log(acc_id, f"⚠️ Неизвестный попап: '{err_popup}' — повтор")
                    driver.execute_script(f"var el=document.querySelector('{SEL_ZABRATY}'); if(el) el.click();")
                    continue

                # Попапа нет — проверяем URL изменился ли (признак успеха)
                cur_url = driver.current_url
                if "activate" not in cur_url:
                    # Ушли со страницы активации — скорее всего успех
                    elapsed = round(time.time() - t_start, 1)
                    log(acc_id, f"✅ Selenium УСПЕХ (смена URL → {cur_url}) за {elapsed}с | {code}")
                    tg_async(f"✅ <b>УСПЕХ! Акк {acc_id}</b> (Selenium)\n🎟 Код: <code>{code}</code>\n⏱ {elapsed}с\n🔗 {cur_url}")
                    activated = True
                    break

                # Остались на странице activate, попапа нет — неоднозначно
                # Проверяем есть ли элемент подтверждения успеха на странице
                success_el = driver.execute_script("""
                    var texts = ['получили', 'активирован', 'зачислен', 'успешно'];
                    var body = (document.body || {}).innerText || '';
                    var lower = body.toLowerCase();
                    for (var t of texts) { if (lower.includes(t)) return t; }
                    return null;
                """)
                if success_el:
                    elapsed = round(time.time() - t_start, 1)
                    log(acc_id, f"✅ Selenium УСПЕХ (текст '{success_el}') за {elapsed}с | {code}")
                    tg_async(f"✅ <b>УСПЕХ! Акк {acc_id}</b> (Selenium)\n🎟 Код: <code>{code}</code>\n⏱ {elapsed}с")
                    activated = True
                    break

                # Попапа нет и страница та же — непонятно что произошло
                log(acc_id, f"⚠️ Попапа нет, URL не изменился — результат неизвестен")
                break

            if activated:
                def return_to_activate(d=driver, aid=acc_id):
                    time.sleep(60)
                    try:
                        d.get(TARGET_URL)
                        log(aid, "Возврат на страницу активации")
                    except Exception:
                        pass
                threading.Thread(target=return_to_activate, daemon=True).start()
                return True

            log(acc_id, f"❌ Selenium: активация не удалась {code}")
            tg_async(f"❌ <b>Акк {acc_id}</b>: не удалось <code>{code}</code>")
            break

        except Exception as e:
            log(acc_id, f"Selenium исключение: {str(e)[:100]}")
            try:
                go_to_activate(driver, wait)
            except Exception:
                pass

    elapsed = round(time.time() - t_start, 1)
    log(acc_id, f"💀 Selenium: все попытки исчерпаны за {elapsed}с")
    tg_async(f"💀 <b>Акк {acc_id}</b>: все попытки исчерпаны ({elapsed}с)")
    try:
        go_to_activate(driver, wait)
    except Exception:
        pass
    return False


# ============================================================
#  РАЗДАЧА
# ============================================================
def distribute_promos(promos: list, irc_time: float = None):
    if not distribute_lock.acquire(timeout=1):
        log(None, "distribute_promos: уже выполняется — пропуск")
        return
    try:
        t_distribute = time.time()
        if irc_time:
            log(None, f"⏱ IRC→distribute: {round(t_distribute - irc_time, 3)}с")

        with drivers_lock:
            available = list(drivers)

        if not available or not promos:
            return

        with promo_pool_lock:
            promo_pool.clear()
            used_promos.clear()
            promo_pool.extend(promos)

        count = min(len(promos), len(available))
        log(None, f"Раздача {count}/{len(promos)} кодов")

        for i in range(count):
            code = claim_next_promo(set())
            if not code:
                break
            threading.Thread(
                target=activate_code,
                args=(available[i], code, i + 1, t_distribute),
                daemon=True
            ).start()
    finally:
        distribute_lock.release()
